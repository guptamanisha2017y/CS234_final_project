# ctde_rllib/ma_merge_env.py
import gymnasium as gym
import highway_env  # registers envs
import numpy as np

from ray.rllib.env.multi_agent_env import MultiAgentEnv


class MultiAgentMergeEnv(MultiAgentEnv):
    """
    Wrap highway-env merge-v0 into RLlib MultiAgentEnv API.

    - Each controlled vehicle is an RL agent: agent_0, agent_1, ...
    - Shared reward: highway-env returns a single scalar reward, we give it to all agents.
    - Shared termination/truncation: same done flag for all agents.
    """

    def __init__(self, env_config=None):
        env_config = env_config or {}
        self.num_agents = int(env_config.get("num_agents", 2))

        # Build a merge-v0 env with multi-agent observation + action configs
        config = {
            "controlled_vehicles": self.num_agents,
            # multi-agent observations
            "observation": {
                "type": "MultiAgentObservation",
                "observation_config": {
                    # keep it simple first; you can swap to Kinematics later
                    "type": "TimeToCollision",
                },
            },
            # multi-agent actions
            "action": {
                "type": "MultiAgentAction",
                "action_config": {
                    "type": "DiscreteMetaAction",
                },
            },
        }

        # Allow user overrides (optional)
        config.update(env_config.get("highway_config", {}))

        self.env = gym.make("merge-v0", config=config)
        obs, _ = self.env.reset()

        # RLlib expects per-agent spaces (use the underlying tuple spaces)
        # multi-agent obs/action spaces in highway-env become Tuple(...)
        self._obs_space = self.env.observation_space
        self._act_space = self.env.action_space

        self.agents = [f"agent_{i}" for i in range(self.num_agents)]

    @property
    def observation_space(self):
        # per-agent obs space is each element of the Tuple
        return self._obs_space

    @property
    def action_space(self):
        return self._act_space

    def reset(self, *, seed=None, options=None):
        obs_tuple, info = self.env.reset(seed=seed)

    # concat all agents’ observations into one central vector
        central = np.concatenate([np.ravel(obs_tuple[i]) for i in range(self.num_agents)], axis=0)

        obs_dict = {}
        for i in range(self.num_agents):
            obs_dict[f"agent_{i}"] = {
                "obs": obs_tuple[i],
                "central_obs": central,
            }
        return obs_dict, info

    def step(self, action_dict):
        actions = tuple(action_dict.get(f"agent_{i}") for i in range(self.num_agents))
        next_obs_tuple, reward, terminated, truncated, info = self.env.step(actions)

        central = np.concatenate([np.ravel(next_obs_tuple[i]) for i in range(self.num_agents)], axis=0)

        next_obs = {}
        for i in range(self.num_agents):
            next_obs[f"agent_{i}"] = {
                "obs": next_obs_tuple[i],
                "central_obs": central,
            }

        rewards = {aid: float(reward) for aid in self.agents}

        terminations = {aid: bool(terminated) for aid in self.agents}
        truncations  = {aid: bool(truncated) for aid in self.agents}
        terminations["__all__"] = bool(terminated)
        truncations["__all__"]  = bool(truncated)

        infos = {aid: dict(info) for aid in self.agents}
        return next_obs, rewards, terminations, truncations, infos

    def close(self):
        self.env.close()