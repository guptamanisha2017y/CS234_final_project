# ctde_rllib/train_mappo.py
import ray
from ray.rllib.algorithms.ppo import PPOConfig
from ray.tune.logger import pretty_print

from ma_merge_env import MultiAgentMergeEnv


def main():
    ray.init(ignore_reinit_error=True)

    # Create a dummy env to grab per-agent spaces
    dummy = MultiAgentMergeEnv({"num_agents": 2})
    obs_space = dummy.env.observation_space.spaces[0]
    act_space = dummy.env.action_space.spaces[0]
    dummy.close()

    policies = {
        "shared_policy": (None, obs_space, act_space, {}),
    }

    def policy_mapping_fn(agent_id, *args, **kwargs):
        return "shared_policy"

    config = (
        PPOConfig()
        .environment(
            env=MultiAgentMergeEnv,
            env_config={
                "num_agents": 2,
                # you can override highway settings here later if you want:
                # "highway_config": { ... }
            },
        )
        .framework("torch")
        .rollouts(num_rollout_workers=0)  # keep local for now (Windows-friendly)
        .training(
            train_batch_size=4000,
            sgd_minibatch_size=256,
            num_sgd_iter=10,
            lr=3e-4,
            gamma=0.99,
            clip_param=0.2,
        )
        .multi_agent(
            policies=policies,
            policy_mapping_fn=policy_mapping_fn,
        )
        .resources(num_gpus=0)
    )

    algo = config.build()

    for i in range(30):
        result = algo.train()
        print(f"\n=== Iteration {i} ===")
        print(pretty_print(result))

        if (i + 1) % 10 == 0:
            checkpoint = algo.save("ctde_rllib_checkpoints")
            print("Saved checkpoint:", checkpoint)

    algo.stop()
    ray.shutdown()


if __name__ == "__main__":
    main()