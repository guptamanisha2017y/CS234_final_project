import numpy as np
import torch
import torch.nn as nn

from ray.rllib.models.torch.torch_modelv2 import TorchModelV2
from ray.rllib.utils.framework import try_import_torch

torch, _ = try_import_torch()


class CentralizedCriticModel(TorchModelV2, nn.Module):
    """
    Actor uses obs["obs"] only.
    Critic uses obs["central_obs"] (joint info) for CTDE.
    """

    def __init__(self, obs_space, action_space, num_outputs, model_config, name):
        TorchModelV2.__init__(self, obs_space, action_space, num_outputs, model_config, name)
        nn.Module.__init__(self)

        # obs_space is a Dict space: {"obs": ..., "central_obs": ...}
        own_obs_dim = int(np.prod(obs_space["obs"].shape))
        central_dim = int(np.prod(obs_space["central_obs"].shape))

        hidden = model_config.get("fcnet_hiddens", [256, 256])

        # Actor network: obs -> action logits
        layers = []
        last = own_obs_dim
        for h in hidden:
            layers += [nn.Linear(last, h), nn.ReLU()]
            last = h
        self.actor_body = nn.Sequential(*layers)
        self.actor_head = nn.Linear(last, num_outputs)

        # Critic network: central_obs -> V(s)
        v_layers = []
        v_last = central_dim
        for h in hidden:
            v_layers += [nn.Linear(v_last, h), nn.ReLU()]
            v_last = h
        self.critic_body = nn.Sequential(*v_layers)
        self.critic_head = nn.Linear(v_last, 1)

        self._last_central = None

    def forward(self, input_dict, state, seq_lens):
        obs = input_dict["obs"]
        own = obs["obs"].float()
        central = obs["central_obs"].float()

        # Flatten just in case
        own = own.view(own.shape[0], -1)
        central = central.view(central.shape[0], -1)

        self._last_central = central

        x = self.actor_body(own)
        logits = self.actor_head(x)
        return logits, state

    def value_function(self):
        assert self._last_central is not None, "value_function() called before forward()"
        v = self.critic_head(self.critic_body(self._last_central))
        return v.squeeze(1)